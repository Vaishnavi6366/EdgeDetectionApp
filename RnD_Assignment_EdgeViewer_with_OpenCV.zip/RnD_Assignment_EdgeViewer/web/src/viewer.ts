export function showFrame(dataUrl: string) {
    const img = document.getElementById('frame') as HTMLImageElement;
    const stats = document.getElementById('stats')!;
    img.src = dataUrl;
    stats.textContent = 'FPS: sample';
}
