#pragma once
#include <vector>
std::vector<unsigned char> edge_detect_rgba(const std::vector<unsigned char>& in, int width, int height);
