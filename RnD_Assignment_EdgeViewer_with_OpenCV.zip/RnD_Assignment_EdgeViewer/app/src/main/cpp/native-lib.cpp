#include <jni.h>
#include <string>
#include <vector>
#include "edge_detection.hpp"

extern "C" JNIEXPORT void JNICALL
Java_com_example_edgeviewer_MainActivity_nativeInit(JNIEnv* env, jobject /* this */) {
    // Placeholder init: nothing to do yet
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_example_edgeviewer_NativeBridge_processFrame(JNIEnv* env, jobject /* this */,
                                                     jbyteArray input, jint width, jint height) {
    jsize len = env->GetArrayLength(input);
    if (len == 0) {
        return env->NewByteArray(0);
    }
    std::vector<unsigned char> buf(len);
    env->GetByteArrayRegion(input, 0, len, reinterpret_cast<jbyte*>(buf.data()));

    std::vector<unsigned char> out = edge_detect_rgba(buf, width, height);

    jbyteArray result = env->NewByteArray(out.size());
    env->SetByteArrayRegion(result, 0, out.size(), reinterpret_cast<const jbyte*>(out.data()));
    return result;
}
