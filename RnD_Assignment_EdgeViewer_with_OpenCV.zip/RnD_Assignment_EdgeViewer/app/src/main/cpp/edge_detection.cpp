#include "edge_detection.hpp"
#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
#include <vector>

using namespace cv;

// Convert RGBA byte vector to cv::Mat, run Canny, convert back to RGBA bytes
std::vector<unsigned char> edge_detect_rgba(const std::vector<unsigned char>& in, int width, int height) {
    if ((int)in.size() < width * height * 4) return std::vector<unsigned char>();

    // Create cv::Mat from RGBA input
    Mat rgba(height, width, CV_8UC4, const_cast<unsigned char*>(in.data()));
    Mat gray;
    cvtColor(rgba, gray, COLOR_RGBA2GRAY);

    Mat edges;
    // Canny parameters: threshold1, threshold2 — you can tune these
    Canny(gray, edges, 80, 160);

    // Convert edges (single channel) back to RGBA to return to Java
    Mat edges_rgba;
    cvtColor(edges, edges_rgba, COLOR_GRAY2RGBA);

    // Copy data to vector
    std::vector<unsigned char> out;
    out.assign(edges_rgba.data, edges_rgba.data + edges_rgba.total() * edges_rgba.elemSize());
    return out;
}
