package com.example.edgeviewer

object NativeBridge {
    init { System.loadLibrary("native-lib") }
    // Expects RGBA bytes (4 * width * height)
    external fun processFrame(input: ByteArray, width: Int, height: Int): ByteArray
}
