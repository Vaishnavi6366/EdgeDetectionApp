package com.example.edgeviewer.gl

import android.opengl.GLES20

class TextureRenderer {
    // Placeholder for texture renderer
    fun init() {}
    fun draw() {}
}
